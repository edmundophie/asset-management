@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.informatika.org/")
package asset;
